extends Node3D

var path_points: Array[Vector3] = []
var game_manager: Node
var enemy_kind := "Normal"
var wave_number := 1
var speed := 1.8
var health := 55.0
var max_health := 55.0
var reward := 12
var target_index := 1
var body_mesh: MeshInstance3D
var health_bar: MeshInstance3D
var health_back: MeshInstance3D
var slow_time := 0.0
var hit_flash := 0.0
var bob_seed := 0.0

func _ready() -> void:
    bob_seed = randf_range(0.0, 10.0)
    match enemy_kind:
        "Swift":
            speed = 2.8 + wave_number * 0.035
            health = 36.0 + wave_number * 5.0
            reward = 15
        "Armored":
            speed = 1.35
            health = 100.0 + wave_number * 12.0
            reward = 22
        "Boss":
            speed = 0.95
            health = 520.0 + wave_number * 45.0
            reward = 120
        _:
            speed = 1.8 + wave_number * 0.025
            health = 55.0 + wave_number * 9.0
            reward = 12 + wave_number
    max_health = health
    _make_model()

func _process(delta: float) -> void:
    if slow_time > 0.0:
        slow_time -= delta
        if slow_time <= 0.0:
            speed = _base_speed()
    if path_points.size() < 2:
        return
    if target_index >= path_points.size():
        if game_manager:
            game_manager.enemy_reached_end(self)
        queue_free()
        return
    var target: Vector3 = path_points[target_index]
    var direction := target - global_position
    direction.y = 0
    if direction.length() < 0.16:
        target_index += 1
        return
    global_position += direction.normalized() * speed * delta
    body_mesh.rotation.y = atan2(direction.x, direction.z)
    body_mesh.position.y = 0.52 + sin(Time.get_ticks_msec() / 145.0 + bob_seed) * 0.065
    body_mesh.rotation.z = sin(Time.get_ticks_msec() / 230.0 + bob_seed) * 0.04
    _update_health_bar()

func _base_speed() -> float:
    match enemy_kind:
        "Swift": return 2.8 + wave_number * 0.035
        "Armored": return 1.35
        "Boss": return 0.95
        _: return 1.8 + wave_number * 0.025

func _make_model() -> void:
    body_mesh = MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.48 if enemy_kind != "Boss" else 0.85
    mesh.height = 0.88 if enemy_kind != "Boss" else 1.45
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.52
    var mat := StandardMaterial3D.new()
    match enemy_kind:
        "Swift": mat.albedo_color = Color(1.0, 0.70, 0.24)
        "Armored":
            mat.albedo_color = Color(0.48, 0.52, 0.60)
            mat.metallic = 0.35
        "Boss":
            mat.albedo_color = Color(0.64, 0.20, 0.70)
            mat.emission_enabled = true
            mat.emission = Color(0.16, 0.025, 0.20)
        _: mat.albedo_color = Color(0.27, 0.84, 0.39)
    mat.roughness = 0.42
    body_mesh.material_override = mat
    add_child(body_mesh)

    for side in [-1, 1]:
        var eye := MeshInstance3D.new()
        var eye_mesh := SphereMesh.new()
        eye_mesh.radius = 0.09 if enemy_kind != "Boss" else 0.14
        eye_mesh.height = 0.14 if enemy_kind != "Boss" else 0.20
        eye.mesh = eye_mesh
        eye.position = Vector3(side * (0.16 if enemy_kind != "Boss" else 0.30), 0.64 if enemy_kind != "Boss" else 0.83, 0.35 if enemy_kind != "Boss" else 0.65)
        var eye_mat := StandardMaterial3D.new()
        eye_mat.albedo_color = Color(0.08, 0.06, 0.10)
        eye.material_override = eye_mat
        add_child(eye)

    if enemy_kind == "Armored" or enemy_kind == "Boss":
        for side in [-1, 1]:
            var horn := MeshInstance3D.new()
            var horn_mesh := PrismMesh.new()
            horn_mesh.size = Vector3(0.24, 0.42, 0.24) if enemy_kind == "Armored" else Vector3(0.38, 0.58, 0.38)
            horn.mesh = horn_mesh
            horn.position = Vector3(side * (0.28 if enemy_kind == "Armored" else 0.52), 1.0 if enemy_kind == "Armored" else 1.4, 0)
            var horn_mat := StandardMaterial3D.new()
            horn_mat.albedo_color = Color(0.78,0.80,0.86) if enemy_kind == "Armored" else Color(0.98,0.45,0.22)
            horn.material_override = horn_mat
            add_child(horn)

    health_back = MeshInstance3D.new()
    var back_mesh := BoxMesh.new()
    back_mesh.size = Vector3(1.0, 0.10, 0.08) if enemy_kind != "Boss" else Vector3(1.65, 0.13, 0.08)
    health_back.mesh = back_mesh
    health_back.position = Vector3(0, 1.16 if enemy_kind != "Boss" else 1.9, 0)
    var back_mat := StandardMaterial3D.new()
    back_mat.albedo_color = Color(0.16, 0.09, 0.10)
    health_back.material_override = back_mat
    add_child(health_back)
    health_bar = MeshInstance3D.new()
    var bar_mesh := BoxMesh.new()
    bar_mesh.size = Vector3(0.92, 0.07, 0.09) if enemy_kind != "Boss" else Vector3(1.55, 0.09, 0.09)
    health_bar.mesh = bar_mesh
    health_bar.position = Vector3(0, 1.17 if enemy_kind != "Boss" else 1.91, 0.05)
    var health_mat := StandardMaterial3D.new()
    health_mat.albedo_color = Color(0.23, 0.95, 0.28) if enemy_kind != "Boss" else Color(0.98, 0.22, 0.20)
    health_mat.emission_enabled = true
    health_mat.emission = health_mat.albedo_color * 0.25
    health_bar.material_override = health_mat
    add_child(health_bar)

func take_damage(amount: float, kind: String = "Arrow") -> void:
    if not is_inside_tree():
        return
    health -= amount
    if kind == "Frost":
        speed = _base_speed() * 0.52
        slow_time = 1.2
    if health <= 0.0:
        if game_manager:
            game_manager.enemy_defeated(self, reward)
        queue_free()
    else:
        _update_health_bar()

func _update_health_bar() -> void:
    if health_bar:
        var ratio := clamp(health / max_health, 0.0, 1.0)
        health_bar.scale.x = max(0.01, ratio)
        var full_width := 0.92 if enemy_kind != "Boss" else 1.55
        health_bar.position.x = -(full_width * 0.5) * (1.0 - ratio)
