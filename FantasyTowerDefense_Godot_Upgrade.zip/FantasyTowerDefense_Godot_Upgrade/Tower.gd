extends Node3D

var tower_type := "Arrow"
var game_manager: Node
var attack_range := 4.8
var damage := 18.0
var cooldown := 0.0
var fire_rate := 0.85
var level := 1
var invested_gold := 60
var is_selected := false
var head: Node3D
var selection_ring: MeshInstance3D
var glow: MeshInstance3D

func _ready() -> void:
    match tower_type:
        "Frost":
            attack_range = 4.3
            damage = 10.0
            fire_rate = 1.05
            invested_gold = 85
        "Fire":
            attack_range = 3.8
            damage = 25.0
            fire_rate = 1.18
            invested_gold = 100
    _make_model()

func _process(delta: float) -> void:
    cooldown -= delta
    if selection_ring:
        selection_ring.visible = is_selected
    var target := _find_target()
    if target and is_instance_valid(target):
        var direction: Vector3 = target.global_position - global_position
        direction.y = 0
        if direction.length() > 0.01 and head:
            head.rotation.y = lerp_angle(head.rotation.y, atan2(direction.x, direction.z), min(1.0, delta * 8.0))
        if cooldown <= 0.0:
            _shoot(target)
            cooldown = fire_rate

func _find_target() -> Node3D:
    if not game_manager:
        return null
    var best: Node3D = null
    var best_dist := attack_range
    for enemy in game_manager.enemies:
        if is_instance_valid(enemy):
            var d := Vector2(global_position.x - enemy.global_position.x, global_position.z - enemy.global_position.z).length()
            if d < best_dist:
                best_dist = d
                best = enemy
    return best

func _make_model() -> void:
    var base := MeshInstance3D.new()
    var base_mesh := CylinderMesh.new()
    base_mesh.top_radius = 0.48
    base_mesh.bottom_radius = 0.67
    base_mesh.height = 0.42
    base.mesh = base_mesh
    base.position.y = 0.27
    var base_mat := StandardMaterial3D.new()
    base_mat.albedo_color = Color(0.43, 0.27, 0.16)
    base_mat.roughness = 0.7
    base.material_override = base_mat
    add_child(base)

    var trim := MeshInstance3D.new()
    var trim_mesh := CylinderMesh.new()
    trim_mesh.top_radius = 0.52
    trim_mesh.bottom_radius = 0.56
    trim_mesh.height = 0.11
    trim.mesh = trim_mesh
    trim.position.y = 0.48
    var trim_mat := StandardMaterial3D.new()
    trim_mat.albedo_color = Color(0.91, 0.70, 0.28)
    trim.material_override = trim_mat
    add_child(trim)

    head = Node3D.new()
    head.position.y = 0.58
    add_child(head)
    var head_mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.39
    sphere.height = 0.72
    head_mesh.mesh = sphere
    var head_mat := StandardMaterial3D.new()
    match tower_type:
        "Frost":
            head_mat.albedo_color = Color(0.25, 0.74, 1.0)
            head_mat.emission_enabled = true
            head_mat.emission = Color(0.04, 0.24, 0.48)
        "Fire":
            head_mat.albedo_color = Color(1.0, 0.36, 0.12)
            head_mat.emission_enabled = true
            head_mat.emission = Color(0.40, 0.055, 0.005)
        _:
            head_mat.albedo_color = Color(0.93, 0.71, 0.28)
    head_mesh.material_override = head_mat
    head.add_child(head_mesh)

    var barrel := MeshInstance3D.new()
    var barrel_mesh := CylinderMesh.new()
    barrel_mesh.top_radius = 0.09
    barrel_mesh.bottom_radius = 0.15
    barrel_mesh.height = 0.70
    barrel.mesh = barrel_mesh
    barrel.rotation_degrees.x = 90
    barrel.position.z = 0.43
    var barrel_mat := StandardMaterial3D.new()
    barrel_mat.albedo_color = Color(0.30, 0.23, 0.16)
    barrel.material_override = barrel_mat
    head.add_child(barrel)

    var jewel := MeshInstance3D.new()
    var jewel_mesh := SphereMesh.new()
    jewel_mesh.radius = 0.13
    jewel_mesh.height = 0.22
    jewel.mesh = jewel_mesh
    jewel.position.y = 0.34
    var jewel_mat := StandardMaterial3D.new()
    jewel_mat.albedo_color = Color(0.45, 1.0, 1.0) if tower_type == "Frost" else (Color(1.0,0.55,0.18) if tower_type == "Fire" else Color(1.0,0.9,0.5))
    jewel_mat.emission_enabled = true
    jewel_mat.emission = jewel_mat.albedo_color * 0.5
    jewel.material_override = jewel_mat
    head.add_child(jewel)

    selection_ring = MeshInstance3D.new()
    var ring_mesh := CylinderMesh.new()
    ring_mesh.top_radius = attack_range
    ring_mesh.bottom_radius = attack_range
    ring_mesh.height = 0.025
    selection_ring.mesh = ring_mesh
    selection_ring.position.y = 0.04
    var ring_mat := StandardMaterial3D.new()
    ring_mat.albedo_color = Color(0.25, 0.92, 1.0, 0.20)
    ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    selection_ring.material_override = ring_mat
    selection_ring.visible = false
    add_child(selection_ring)

    var level_badge := MeshInstance3D.new()
    var badge_mesh := SphereMesh.new()
    badge_mesh.radius = 0.15
    badge_mesh.height = 0.24
    level_badge.mesh = badge_mesh
    level_badge.position = Vector3(0.35, 1.0, 0)
    var badge_mat := StandardMaterial3D.new()
    badge_mat.albedo_color = Color(1.0, 0.86, 0.25)
    badge_mat.emission_enabled = true
    badge_mat.emission = Color(0.28, 0.17, 0.01)
    level_badge.material_override = badge_mat
    add_child(level_badge)

func upgrade_tower() -> void:
    if level >= 5:
        if game_manager:
            game_manager.call("_show_message", "这座塔已经达到最高等级！")
        return
    level += 1
    damage *= 1.38
    attack_range += 0.25
    fire_rate = max(0.32, fire_rate * 0.92)
    invested_gold += (level - 1) * 55
    if selection_ring and selection_ring.mesh is CylinderMesh:
        selection_ring.mesh.top_radius = attack_range
        selection_ring.mesh.bottom_radius = attack_range
    scale = Vector3.ONE * (1.0 + (level - 1) * 0.035)

func _shoot(target: Node3D) -> void:
    if not is_instance_valid(target):
        return
    var projectile := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.13 if tower_type != "Fire" else 0.20
    mesh.height = mesh.radius * 2.0
    projectile.mesh = mesh
    var mat := StandardMaterial3D.new()
    match tower_type:
        "Frost":
            mat.albedo_color = Color(0.45, 0.90, 1.0)
            mat.emission_enabled = true
            mat.emission = Color(0.1, 0.45, 0.8)
        "Fire":
            mat.albedo_color = Color(1.0, 0.30, 0.06)
            mat.emission_enabled = true
            mat.emission = Color(0.8, 0.12, 0.01)
        _:
            mat.albedo_color = Color(1.0, 0.88, 0.36)
            mat.emission_enabled = true
            mat.emission = Color(0.25, 0.16, 0.025)
    projectile.material_override = mat
    projectile.global_position = global_position + Vector3(0, 0.9, 0)
    get_tree().current_scene.add_child(projectile)
    var finish: Vector3 = target.global_position + Vector3(0, 0.45, 0)
    var duration := max(0.12, projectile.global_position.distance_to(finish) / 18.0)
    var tween := create_tween()
    tween.tween_property(projectile, "global_position", finish, duration)
    tween.tween_callback(func():
        if is_instance_valid(target):
            target.take_damage(damage, tower_type)
        if is_instance_valid(projectile):
            _impact_spark(finish)
            projectile.queue_free()
    )

func _impact_spark(pos: Vector3) -> void:
    var spark := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.16 if tower_type == "Arrow" else 0.24
    mesh.height = mesh.radius * 2.0
    spark.mesh = mesh
    spark.global_position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.55,0.9,1) if tower_type == "Frost" else (Color(1,0.35,0.08) if tower_type == "Fire" else Color(1,0.9,0.4))
    mat.emission_enabled = true
    mat.emission = mat.albedo_color
    spark.material_override = mat
    get_tree().current_scene.add_child(spark)
    var tween := create_tween()
    tween.tween_property(spark, "scale", Vector3(1.8,1.8,1.8), 0.16)
    tween.tween_callback(spark.queue_free)
