extends Node3D

const ENEMY_SCRIPT = preload("res://Enemy.gd")
const TOWER_SCRIPT = preload("res://Tower.gd")

var gold := 220
var lives := 15
var wave := 0
var enemies_spawned := 0
var enemies_to_spawn := 0
var spawn_timer := 0.0
var wave_active := false
var selected_tower := "Arrow"
var towers: Array[Node3D] = []
var enemies: Array[Node3D] = []
var build_spots: Array[Vector3] = []
var path_points: Array[Vector3] = [
    Vector3(-10, 0.15, -6), Vector3(-5, 0.15, -6),
    Vector3(-5, 0.15, -2), Vector3(1, 0.15, -2),
    Vector3(1, 0.15, 3), Vector3(6, 0.15, 3),
    Vector3(6, 0.15, 6), Vector3(10, 0.15, 6)
]
var selected_tower_node: Node3D = null
var gold_label: Label
var status_label: Label
var wave_button: Button
var upgrade_button: Button
var sell_button: Button
var speed_button: Button
var game_over := false
var game_speed := 1.0
var camera: Camera3D
var spot_visuals: Array[MeshInstance3D] = []

func _ready() -> void:
    randomize()
    _make_world()
    _make_ui()
    _update_ui()
    _show_message("欢迎来到奇幻森林！选择塔，再点击金色建造台。")

func _process(delta: float) -> void:
    if game_over:
        return
    if wave_active:
        spawn_timer -= delta
        if enemies_spawned < enemies_to_spawn and spawn_timer <= 0.0:
            _spawn_enemy()
            enemies_spawned += 1
            spawn_timer = max(0.42, 1.12 - wave * 0.025)
        if enemies_spawned >= enemies_to_spawn and enemies.is_empty():
            wave_active = false
            gold += 35 + wave * 8
            _update_ui()
            _show_message("第 %d 波完成！获得 %d 枚奖励金币。" % [wave, 35 + wave * 8])
            wave_button.text = "开始第 %d 波" % (wave + 1)

func _make_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.20, 0.43, 0.78)
    sky_mat.sky_horizon_color = Color(0.78, 0.88, 0.98)
    sky_mat.ground_bottom_color = Color(0.20, 0.28, 0.20)
    sky_mat.ground_horizon_color = Color(0.58, 0.69, 0.45)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.78, 0.86, 1.0)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    add_child(sun)

    _box("Meadow", Vector3(0, -0.35, 0), Vector3(25, 0.6, 18), Color(0.25, 0.57, 0.28))
    _make_path()
    build_spots = [Vector3(-8, 0.3, -3.7), Vector3(-2.8, 0.3, -4.2), Vector3(-2.8, 0.3, 0.1), Vector3(3.2, 0.3, -0.1), Vector3(4.2, 0.3, 4.8), Vector3(8.0, 0.3, 3.9)]
    _make_decorations()
    for i in range(build_spots.size()):
        _make_build_spot(build_spots[i], i)

    camera = Camera3D.new()
    camera.position = Vector3(0, 17, 20)
    camera.rotation_degrees = Vector3(-42, 0, 0)
    camera.current = true
    camera.fov = 48
    add_child(camera)

func _box(label: String, pos: Vector3, size: Vector3, color: Color, parent: Node = self) -> MeshInstance3D:
    var inst := MeshInstance3D.new()
    inst.name = label
    var mesh := BoxMesh.new()
    mesh.size = size
    inst.mesh = mesh
    inst.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.88
    inst.material_override = mat
    parent.add_child(inst)
    return inst

func _make_path() -> void:
    for i in range(path_points.size() - 1):
        var a: Vector3 = path_points[i]
        var b: Vector3 = path_points[i + 1]
        var mid := (a + b) / 2.0
        var length := a.distance_to(b)
        var vertical := abs(b.z - a.z) > abs(b.x - a.x)
        var road := _box("Path_%d" % i, Vector3(mid.x, 0.015, mid.z), Vector3(1.85 if vertical else length + 0.12, 0.20, length + 0.12 if vertical else 1.85), Color(0.60, 0.43, 0.26))
        road.position.y = 0.015
        _box("PathEdge_%d" % i, Vector3(mid.x, 0.12, mid.z), Vector3(1.45 if vertical else length, 0.035, length if vertical else 1.45), Color(0.78, 0.64, 0.42))
        # Small stepping stones make the path read better from the isometric camera.
        var count := int(length / 1.1)
        for j in range(count):
            var t := (float(j) + 0.5) / max(1.0, float(count))
            var p := a.lerp(b, t)
            var stone := _box("Stone", Vector3(p.x, 0.14, p.z), Vector3(0.18, 0.025, 0.32), Color(0.87, 0.75, 0.54))
            if vertical:
                stone.rotation_degrees.y = 90

func _make_decorations() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 3217
    for i in range(32):
        var p := Vector3(rng.randf_range(-11.5, 11.5), 0, rng.randf_range(-8.0, 8.0))
        if _near_path(p) or _near_build_spot(p):
            continue
        _make_tree(p, rng.randf_range(0.72, 1.22), i)
    # Bushes and flower patches add color without heavy textures.
    for i in range(24):
        var p := Vector3(rng.randf_range(-11.0, 11.0), 0.08, rng.randf_range(-7.5, 7.5))
        if _near_path(p) or _near_build_spot(p):
            continue
        var bush := MeshInstance3D.new()
        var bm := SphereMesh.new()
        bm.radius = rng.randf_range(0.18, 0.32)
        bm.height = bm.radius * 1.7
        bush.mesh = bm
        bush.position = p
        var material := StandardMaterial3D.new()
        material.albedo_color = [Color(0.22,0.48,0.19), Color(0.34,0.60,0.24), Color(0.50,0.67,0.25)][rng.randi_range(0,2)]
        bush.material_override = material
        add_child(bush)
    # Magical crystal gate marks the exit.
    for i in range(3):
        var crystal := MeshInstance3D.new()
        var cm := PrismMesh.new()
        cm.size = Vector3(0.55, 1.35 + i * 0.22, 0.55)
        crystal.mesh = cm
        crystal.position = Vector3(10.2 + i * 0.48, 0.72, 7.0)
        crystal.rotation_degrees = Vector3(0, i * 25, 10)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.30, 0.83, 1.0)
        mat.emission_enabled = true
        mat.emission = Color(0.10, 0.50, 0.95)
        crystal.material_override = mat
        add_child(crystal)
    _make_castle()

func _make_tree(p: Vector3, scale_factor: float, index: int) -> void:
    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.13 * scale_factor
    trunk_mesh.bottom_radius = 0.23 * scale_factor
    trunk_mesh.height = 1.15 * scale_factor
    trunk.mesh = trunk_mesh
    trunk.position = p + Vector3(0, 0.57 * scale_factor, 0)
    trunk.rotation_degrees.z = randf_range(-5, 5)
    var bark := StandardMaterial3D.new()
    bark.albedo_color = Color(0.34, 0.20, 0.11)
    trunk.material_override = bark
    add_child(trunk)
    for c in range(3):
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = (0.52 + c * 0.08) * scale_factor
        crown_mesh.height = 1.18 * scale_factor
        crown.mesh = crown_mesh
        crown.position = p + Vector3((c - 1) * 0.30 * scale_factor, (1.25 + (c % 2) * 0.28) * scale_factor, 0)
        var leaves := StandardMaterial3D.new()
        leaves.albedo_color = [Color(0.10,0.39,0.16), Color(0.15,0.49,0.19), Color(0.24,0.57,0.22)][index % 3]
        crown.material_override = leaves
        add_child(crown)

func _make_castle() -> void:
    var stone := StandardMaterial3D.new()
    stone.albedo_color = Color(0.72, 0.75, 0.80)
    _box("CastleKeep", Vector3(10.5, 0.65, 7.8), Vector3(2.0, 1.3, 1.7), Color(0.70,0.74,0.82))
    for dx in [-0.72, 0.72]:
        var tower := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = 0.28
        cyl.bottom_radius = 0.34
        cyl.height = 1.8
        tower.mesh = cyl
        tower.position = Vector3(10.5 + dx, 0.9, 7.6)
        tower.material_override = stone
        add_child(tower)
        var roof := MeshInstance3D.new()
        var cone := PrismMesh.new()
        cone.size = Vector3(0.72, 0.75, 0.72)
        roof.mesh = cone
        roof.position = tower.position + Vector3(0, 1.05, 0)
        var roof_mat := StandardMaterial3D.new()
        roof_mat.albedo_color = Color(0.67, 0.22, 0.22)
        roof.material_override = roof_mat
        add_child(roof)

func _near_path(p: Vector3) -> bool:
    for point in path_points:
        if Vector2(p.x - point.x, p.z - point.z).length() < 2.0:
            return true
    return false

func _near_build_spot(p: Vector3) -> bool:
    for spot in build_spots:
        if Vector2(p.x - spot.x, p.z - spot.z).length() < 1.5:
            return true
    return false

func _make_build_spot(p: Vector3, index: int) -> void:
    var base := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.70
    mesh.bottom_radius = 0.82
    mesh.height = 0.16
    base.mesh = mesh
    base.position = p
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.91, 0.73, 0.30)
    mat.roughness = 0.65
    base.material_override = mat
    add_child(base)
    spot_visuals.append(base)
    var gem := MeshInstance3D.new()
    var gm := SphereMesh.new()
    gm.radius = 0.12
    gm.height = 0.22
    gem.mesh = gm
    gem.position = p + Vector3(0, 0.15, 0)
    var gmat := StandardMaterial3D.new()
    gmat.albedo_color = Color(1.0, 0.92, 0.53)
    gmat.emission_enabled = true
    gmat.emission = Color(0.38, 0.24, 0.04)
    gem.material_override = gmat
    add_child(gem)

func _unhandled_input(event: InputEvent) -> void:
    var screen_pos := Vector2.ZERO
    var pressed := false
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        screen_pos = event.position
        pressed = true
    elif event is InputEventScreenTouch and event.pressed:
        screen_pos = event.position
        pressed = true
    if pressed:
        _handle_world_tap(screen_pos)

func _handle_world_tap(screen_pos: Vector2) -> void:
    if camera == null:
        return
    var origin := camera.project_ray_origin(screen_pos)
    var direction := camera.project_ray_normal(screen_pos)
    if abs(direction.y) < 0.001:
        return
    var t := (0.3 - origin.y) / direction.y
    if t < 0:
        return
    var hit := origin + direction * t
    var nearest_index := -1
    var nearest_distance := 1.2
    for i in range(build_spots.size()):
        var d := Vector2(hit.x - build_spots[i].x, hit.z - build_spots[i].z).length()
        if d < nearest_distance:
            nearest_distance = d
            nearest_index = i
    if nearest_index >= 0:
        var existing := _tower_at(build_spots[nearest_index])
        if existing != null:
            _select_existing_tower(existing)
        else:
            _build_tower(nearest_index)

func _tower_at(pos: Vector3) -> Node3D:
    for tower in towers:
        if is_instance_valid(tower) and Vector2(tower.global_position.x - pos.x, tower.global_position.z - pos.z).length() < 0.8:
            return tower
    return null

func _build_tower(index: int) -> void:
    if game_over:
        return
    var pos: Vector3 = build_spots[index]
    var costs := {"Arrow": 60, "Frost": 85, "Fire": 100}
    var cost: int = costs.get(selected_tower, 60)
    if gold < cost:
        _show_message("金币不足！还需要 %d 枚金币。" % (cost - gold))
        return
    gold -= cost
    var tower: Node3D = TOWER_SCRIPT.new()
    tower.position = pos
    tower.set("tower_type", selected_tower)
    tower.set("game_manager", self)
    add_child(tower)
    towers.append(tower)
    _select_existing_tower(tower)
    _update_ui()
    _show_message("建造成功：%s塔。点击已建造的塔可以升级或出售。" % _tower_name(selected_tower))

func _select_existing_tower(tower: Node3D) -> void:
    selected_tower_node = tower
    upgrade_button.disabled = false
    sell_button.disabled = false
    upgrade_button.text = "升级（%d）" % int(tower.get("level") * 55)
    for item in towers:
        if is_instance_valid(item):
            item.set("is_selected", item == tower)
    _show_message("已选中%s塔 · 等级 %d" % [_tower_name(tower.get("tower_type")), tower.get("level")])

func upgrade_selected_tower() -> void:
    if not is_instance_valid(selected_tower_node):
        _show_message("请先点击地图上已有的炮塔。")
        return
    if int(selected_tower_node.get("level")) >= 5:
        _show_message("这座塔已经达到最高等级！")
        return
    var cost := int(selected_tower_node.get("level") * 55)
    if gold < cost:
        _show_message("金币不足，升级需要 %d 枚金币。" % cost)
        return
    gold -= cost
    selected_tower_node.call("upgrade_tower")
    upgrade_button.text = "升级（%d）" % int(selected_tower_node.get("level") * 55)
    _update_ui()
    _show_message("升级成功！当前等级：%d" % selected_tower_node.get("level"))

func sell_selected_tower() -> void:
    if not is_instance_valid(selected_tower_node):
        return
    var refund := int(selected_tower_node.get("invested_gold") * 0.65)
    gold += refund
    towers.erase(selected_tower_node)
    selected_tower_node.queue_free()
    selected_tower_node = null
    upgrade_button.disabled = true
    sell_button.disabled = true
    _update_ui()
    _show_message("炮塔已出售，返还 %d 枚金币。" % refund)

func _tower_name(kind: String) -> String:
    return {"Arrow":"神射", "Frost":"寒冰", "Fire":"烈焰"}.get(kind, kind)

func _spawn_enemy() -> void:
    var enemy: Node3D = ENEMY_SCRIPT.new()
    enemy.path_points = path_points
    enemy.game_manager = self
    enemy.position = path_points[0]
    enemy.wave_number = wave
    if wave % 5 == 0 and enemies_spawned == 0:
        enemy.enemy_kind = "Boss"
    elif wave >= 3 and enemies_spawned % 4 == 2:
        enemy.enemy_kind = "Armored"
    elif enemies_spawned % 3 == 1:
        enemy.enemy_kind = "Swift"
    add_child(enemy)
    enemies.append(enemy)

func enemy_reached_end(enemy: Node3D) -> void:
    enemies.erase(enemy)
    lives -= 1 if enemy.get("enemy_kind") != "Boss" else 3
    _update_ui()
    if lives <= 0:
        lives = 0
        game_over = true
        wave_active = false
        _show_message("城堡失守！点击重新开始再挑战。")
        wave_button.text = "重新开始"

func enemy_defeated(enemy: Node3D, reward: int) -> void:
    enemies.erase(enemy)
    gold += reward
    _update_ui()

func start_wave() -> void:
    if game_over:
        get_tree().reload_current_scene()
        return
    if wave_active:
        _show_message("当前波次还在进行中。")
        return
    wave += 1
    enemies_spawned = 0
    enemies_to_spawn = 6 + wave * 2
    spawn_timer = 0.15
    wave_active = true
    wave_button.text = "第 %d 波进行中" % wave
    _update_ui()
    if wave % 5 == 0:
        _show_message("⚠ BOSS 来袭！集中火力保护城堡！")
    else:
        _show_message("第 %d 波怪物来袭！敌人数量：%d" % [wave, enemies_to_spawn])

func toggle_speed() -> void:
    game_speed = 2.0 if game_speed == 1.0 else 1.0
    Engine.time_scale = game_speed
    speed_button.text = "速度：2倍" if game_speed == 2.0 else "速度：1倍"

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var top_panel := PanelContainer.new()
    top_panel.position = Vector2(16, 12)
    top_panel.custom_minimum_size = Vector2(370, 88)
    layer.add_child(top_panel)
    var vbox := VBoxContainer.new()
    top_panel.add_child(vbox)
    gold_label = Label.new()
    gold_label.add_theme_font_size_override("font_size", 20)
    vbox.add_child(gold_label)
    status_label = Label.new()
    status_label.add_theme_font_size_override("font_size", 16)
    vbox.add_child(status_label)

    var bottom_panel := PanelContainer.new()
    bottom_panel.anchor_left = 0.0
    bottom_panel.anchor_right = 1.0
    bottom_panel.anchor_top = 1.0
    bottom_panel.anchor_bottom = 1.0
    bottom_panel.offset_left = 10
    bottom_panel.offset_right = -10
    bottom_panel.offset_top = -88
    bottom_panel.offset_bottom = -8
    layer.add_child(bottom_panel)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 7)
    bottom_panel.add_child(row)
    var title := Label.new()
    title.text = "建造："
    title.add_theme_font_size_override("font_size", 17)
    row.add_child(title)
    for info in [["Arrow","🏹 神射 60"],["Frost","❄ 寒冰 85"],["Fire","🔥 烈焰 100"]]:
        var button := Button.new()
        button.text = info[1]
        button.custom_minimum_size = Vector2(130, 54)
        button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        button.pressed.connect(_select_tower.bind(info[0]))
        row.add_child(button)
    upgrade_button = Button.new()
    upgrade_button.text = "升级"
    upgrade_button.disabled = true
    upgrade_button.custom_minimum_size = Vector2(105, 54)
    upgrade_button.pressed.connect(upgrade_selected_tower)
    row.add_child(upgrade_button)
    sell_button = Button.new()
    sell_button.text = "出售"
    sell_button.disabled = true
    sell_button.custom_minimum_size = Vector2(80, 54)
    sell_button.pressed.connect(sell_selected_tower)
    row.add_child(sell_button)
    speed_button = Button.new()
    speed_button.text = "速度：1倍"
    speed_button.custom_minimum_size = Vector2(105, 54)
    speed_button.pressed.connect(toggle_speed)
    row.add_child(speed_button)
    wave_button = Button.new()
    wave_button.text = "开始第 1 波"
    wave_button.custom_minimum_size = Vector2(145, 54)
    wave_button.pressed.connect(start_wave)
    row.add_child(wave_button)

func _select_tower(kind: String) -> void:
    selected_tower = kind
    _show_message("已选择%s塔。点击地图上的金色建造台放置。" % _tower_name(kind))

func _update_ui() -> void:
    if gold_label:
        gold_label.text = "💎 金币：%d     ❤️ 城堡生命：%d" % [gold, lives]
    if status_label:
        status_label.text = "🌊 第 %d 波    👾 场上怪物：%d" % [wave, enemies.size()]

func _show_message(msg: String) -> void:
    if status_label:
        status_label.text = msg
